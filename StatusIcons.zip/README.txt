Unzip 57.DAT to:
Program Files (x86)\PlayOnline\SquareEnix\FINAL FANTASY XI\ROM\119

(please remember to back up your original files)



The icon folder is for people who use PartyBuffs and would like the icon sets to match.